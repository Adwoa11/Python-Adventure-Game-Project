import time
import random

weapons = ["magical Sword of Ogoroth"]


def print_pause(message, delay=2):
    print(message)
    time.sleep(delay)


def intro(animals):
    print_pause("\nYou find yourself standing in an open field"
                ", filled with grass and yellow wildflowers.")
    print_pause(f"Rumor has it that a {animals} is somewhere"
                " around here, and has been terrifying the nearby village.")
    print_pause("In front of you is a house.")
    print_pause("To your right is a dark cave.")
    print_pause("In your hand you hold your"
                " trusty (but not very effective) dagger.")


def preference(animals, weapons):
    print_pause("\nEnter 1 to knock on the door of the house")
    print_pause("Enter 2 to peer into the cave")
    print_pause("What would you like to do?")
    select_residence_or_grotto(animals, weapons)


def select_residence_or_grotto(animals, weapons):
    residence_or_grotto = valid_input("(Please enter): (1 or 2)\n", ["1", "2"])
    if residence_or_grotto == "1":
        residence(animals, weapons)
    elif residence_or_grotto == "2":
        grotto(animals, weapons)
    else:
        preference(animals, weapons)


def residence(animals, weapons):
    if "magical Sword of Ogoroth" in weapons:
        print_pause("You approach the door of the house.")
        print_pause("You are about to knock"
                    f" when the door opens and steps out a {animals}")
        print_pause(f"Eep! This is the {animals} house.")
        print_pause(f"The {animals} attacks you")
    else:
        print_pause("You approach the door of the house.")
        print_pause("You are about to knock"
                    f" when the door opens and steps out a {animals}")
        print_pause(f"Eep! This is the {animals} house")
        print_pause(f"The {animals} attacks you")
        print_pause("You feel a bit unprepared"
                    " for this, what with only having a tiny dagger")
    attack_or_withdraw(animals, weapons)


def valid_input(prompt, options):
    while True:
        option = input(prompt).lower()
        if option in options:
            return option
        print_pause(f"Sorry, the option {option} is invalid. Try again")


def attack_or_withdraw(animals, weapons):
    answer = valid_input("\nWould you like to (1) fight or (2)"
                         " run away? : (1/2)", ["1", "2"])
    if answer == "1":
        attack(animals, weapons)
    elif answer == "2":
        withdraw(animals, weapons)
    else:
        attack_or_withdraw(animals, weapons)


def attack(animals, weapons):
    if "magical Sword of Ogoroth" in weapons:
        print_pause(f"As the {animals} moves"
                    " to attack, you unsheath your new sword")
        print_pause("The Sword of Ogoroth shines brightly"
                    " in your hand as you brace yourself for the attack")
        print_pause(f"But the {animals} takes one"
                    " look at your shiny new toy and runs away!")
        print_pause("You have rid the town"
                    f" of the {animals}. You are victorious!")
    else:
        print_pause("You do your best...")
        print_pause(f"But your dagger is no match for the {animals}.")
        print_pause("You have been defeated!")
        weapons.append("magical Sword of Ogoroth")
    replay()


def withdraw(animals, weapons):
    print_pause("You run back into the field."
                " Luckily, you don't seem to have been followed.")
    preference(animals, weapons)


def grotto(animals, weapons):
    if "magical Sword of Ogoroth" in weapons:
        print_pause("You peer cautiously into the cave.")
        print_pause("You've been here before, and gotten"
                    " all the good stuff. It's just an empty cave now.")
        print_pause("You walk back out to the field")
    else:
        print_pause("You peer cautiously into the cave.")
        print_pause("It turns out to be a very small cave.")
        print_pause("Your eye catches a glint of metal behind a rock.")
        print_pause("You have found the magical Sword of Ogoroth!")
        print_pause("You discard your silly old dagger"
                    " and take the sword with you")
        print_pause("You walk back out to the field")
        weapons.append("magical Sword of Ogoroth")
    preference(animals, weapons)


def replay():
    choice = valid_input("Would you like to play again?: (y/n)", ["y", "n"])
    if choice == "n":
        print_pause("Thanks for playing! See you next time.")
    elif choice == "y":
        print_pause("Excellent! Restarting the game...")
        play_adventure()
    else:
        replay()


def play_adventure():
    creatures = ["dragon", "wicked fairie", "gordon", "troll", "pirate"]
    animals = random.choice(creatures)
    weapons = []
    intro(animals)
    preference(animals, weapons)


if __name__ == "__main__":
    play_adventure()
